# NextInnovation
自我革新，自我修养。